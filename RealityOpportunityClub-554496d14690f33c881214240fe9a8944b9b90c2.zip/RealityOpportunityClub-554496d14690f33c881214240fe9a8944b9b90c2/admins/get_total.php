<?php for ($i=5; $i<=5; $i++){
echo $jithin=$_GET['prdct_id'.$i];
}
?>