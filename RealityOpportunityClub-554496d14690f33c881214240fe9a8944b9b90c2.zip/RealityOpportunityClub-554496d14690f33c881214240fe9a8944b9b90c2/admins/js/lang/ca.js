var fdLocale = {
/* Uncomment the following line if the first day of the week does not start on Monday */
//firstDayOfWeek:0,
fullMonths:["Gener", "Febrer", "Mar\u00E7", "Abril", "Maig", "Juny", "Juliol", "Agost", "Setembre", "Octubre", "Novembre", "Desembre"],
monthAbbrs:["Gen", "Feb", "Mar", "Abr", "Mai", "Jun", "Jul", "Aug", "Set", "Oct", "Nov", "Des"],
fullDays:["Dilluns", "Dimarts", "Dimecres", "Dijous", "Divendres", "Dissabte", "Diumenge"],
dayAbbrs:["Dil", "Dim", "Dx", "Dij", "Div", "Dis", "Diu"],
titles:["Mes anterior", "Pr\u00F2xim mes", "Any anterior", "Pr\u00F2xim any", "Avui", "Mostrar calendari", "sm", "Setmana [[%0%]] de [[%1%]]", "Setmana", "Selecciona una data", "Cliqui \u0026 arrastri per moure", "Mostrar \u201C[[%0%]]\u201D primer", "Ir a la data d\u0027avui", "Data desactivada"]};