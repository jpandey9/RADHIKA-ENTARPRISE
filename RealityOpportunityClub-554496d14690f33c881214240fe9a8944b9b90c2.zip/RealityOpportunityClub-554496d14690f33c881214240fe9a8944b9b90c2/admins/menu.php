<?php 
include("../connect/session.php");
if ($uname == "10")
include("admenu.php");
else if ($uname == "sudha")
include("sdmenu.php");
?>