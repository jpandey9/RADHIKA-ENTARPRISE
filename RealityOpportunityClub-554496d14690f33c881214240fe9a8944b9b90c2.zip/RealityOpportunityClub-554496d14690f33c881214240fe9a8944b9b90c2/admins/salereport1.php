<?php include("../connect/session.php"); $uname=$_SESSION['adminlogin']; ?>
<link href="colours.css" rel="stylesheet" type="text/css" />

<table width="590" border="1" cellpadding="3" cellspacing="1" bordercolor="#9A9A9A" class="Contents">
  <tr>
    <th align="left" valign="middle" scope="col"><div align="center">
      <p>ROP Club</p>
      <p><br />
        Sale Reports: <?php echo date('d-m-Y'); ?><br />
      </p>
    </div></th>
  </tr>
  <tr>
    <th width="224" align="left" valign="middle" scope="row">&nbsp;</th>
  </tr>
</table>
